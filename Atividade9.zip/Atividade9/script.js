let X1 = document.querySelector("#X1");
let Y1 = document.querySelector('#Y1');
let X2 = document.querySelector('#X2');
let Y2 = document.querySelector('#Y2');
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(X1.value);
  let num2 = Number(Y1.value);
  let num3 = Number(X2.value);
  let num4 = Number(Y2.value);
  Resultado.textContent = Math.sqrt(Math.pow(num3 - num1, 2) + Math.pow(num4 - num2, 2).toFixed(2));
}

btCalcular.onclick = function() {
    Calcular();
}