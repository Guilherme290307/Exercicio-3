let Conta = document.querySelector("#Conta");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Conta.value.replace(",", "."));

  let ContaInteira = Math.floor(num1 / 3);
  let Carlos = (ContaInteira);
  let Andre = (ContaInteira);

  let Felipe = ((num1 - Carlos - Andre).toFixed(2))

  Resultado.innerHTML = "Carlos deve pagar: R$: " + Carlos.toFixed(2) + "<br>" + 
  "Andr&eacute; deve pagar: R$: " + Andre.toFixed(2) + "<br>" + 
  "Felipe deve pagar: R$:" + Felipe;
}

btCalcular.onclick = function() {
  Calcular();
}