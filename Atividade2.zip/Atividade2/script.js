let Cavalos = document.querySelector("#Cavalos");
let btCalcularFerraduras = document.querySelector("#btCalcularFerraduras");
let Resultado = document.querySelector("#Resultado");

function CalcularFerraduras() {
  let num1 = Number(Cavalos.value);
  Resultado.textContent = (num1 * 4);
}

btCalcularFerraduras.onclick = function() {
    CalcularFerraduras();
}