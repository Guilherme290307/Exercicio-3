let Salario = document.querySelector("#Salario");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Salario.value.replace(",", "."));
  
  let SalarioComAumento = (num1 * 1.15);
  let SalarioFinal = (SalarioComAumento * 0.92);

  Resultado.innerHTML = "Salário inicial: R$ " + num1.toFixed(2) + "<br>" + 
  "Salário com aumento (15%): R$ " + SalarioComAumento.toFixed(2) + "<br>" + 
  "Salário final após 8% de impostos: R$ " + SalarioFinal.toFixed(2);
}

btCalcular.onclick = function() {
    Calcular();
}