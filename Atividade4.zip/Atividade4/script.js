let Nome = document.querySelector("#Nome");
let Idade = document.querySelector("#Idade");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let text1 = (Nome.value);
  let num1 = Number(Idade.value);

  let DiasVividos = (num1 * 365);

  Resultado.innerHTML = "Nome: " + text1 + "," + " VOCÊ J&Aacute; VIVEU: " + DiasVividos + " DIAS";
}

btCalcular.onclick = function() {
    Calcular();
}