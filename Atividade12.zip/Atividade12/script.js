let Numero = document.querySelector("#Numero");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Numero.value);
  
  let Centena = Math.floor(num1 / 100);
  let Dezena = Math.floor((num1 % 100) / 10);
  let Unidade = (num1 % 10);

  Resultado.innerHTML = "CENTENA: " + Centena + "<br>" + 
  "DEZENA: " + Dezena + "<br>" + 
  "UNIDADE: " + Unidade;
}

btCalcular.onclick = function() {
  Calcular();
}