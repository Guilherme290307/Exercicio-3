let Paes = document.querySelector("#Paes");
let Broas = document.querySelector("#Broas");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Paes.value);
  let num2 = Number(Broas.value);

  let PaesPreco = (0.12);
  let BroasPreco = (1.50);

  let TotalPaes = (num1 * PaesPreco);
  let TotalBroas = (num2 * BroasPreco);
  let Total = (TotalPaes + TotalBroas);

  let Poupanca = (Total * 0.10);

  Resultado.innerHTML = "Total dos Pães: R$:" + TotalPaes.toFixed(2) + "<br>" + 
  "Total das Broas: R$:" + TotalBroas.toFixed(2) + "<br>" + 
  "Total arrecadado: R$:" + Total.toFixed(2) + "<br>" + 
  "Valor a ser guardado na poupança (10%): R$" + Poupanca.toFixed(2);
}

btCalcular.onclick = function() {
    Calcular();
}