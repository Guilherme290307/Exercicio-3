let Dia = document.querySelector("#Dia");
let Mes = document.querySelector('#Mes');
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Dia.value);
  let num2 = Number(Mes.value);
  Resultado.textContent = ((num2 - 1) * 30 + num1);
}

btCalcular.onclick = function() {
    Calcular();
}