let Preco = document.querySelector("#Preco");
let Valor = document.querySelector("#Valor");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Preco.value.replace(",", "."));
  let num2 = Number(Valor.value.replace(",", "."));
  Resultado.textContent = ((num1 / num2).toFixed(2));
}

btCalcular.onclick = function() {
    Calcular();
}