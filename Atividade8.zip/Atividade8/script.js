let P = document.querySelector("#P");
let M = document.querySelector('#M');
let G = document.querySelector('#G');
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(P.value);
  let num2 = Number(M.value);
  let num3 = Number(G.value);
  
  let PrecoP = (10.00);
  let PrecoM = (12.00);
  let PrecoG = (15.00);

  let Total = (num1 * PrecoP) + (num2 * PrecoM) + (num3 * PrecoG);

  Resultado.innerHTML = "Valor arrecadado: R$ " + Total.toFixed(2);
}

btCalcular.onclick = function() {
    Calcular();
}