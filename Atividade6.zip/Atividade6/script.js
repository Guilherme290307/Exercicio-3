let Peso = document.querySelector("#Peso");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Peso.value.replace(",", "."));

  let PrecoPorQuilo = (12.00);

  let Valor = (num1 * PrecoPorQuilo);

  Resultado.textContent = "Valor a pagar: R$ " + Valor.toFixed(2);
}

btCalcular.onclick = function() {
    Calcular();
}