let Raio = document.querySelector("#Raio");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Raio.value);
  let pi = (3.14);
  Resultado.textContent = ((pi * num1 * num1).toFixed(2));
}

btCalcular.onclick = function() {
  Calcular();
}