let Dias = document.querySelector("#Dias");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Dias.value);
  
  let Anos = Math.floor(num1 / 360);
  let RestoDias = (num1 % 360);
  let Meses = Math.floor(RestoDias / 30);
  let dias = (RestoDias % 30);

  Resultado.innerHTML = "Tempo sem acidentes:" + "<br>" + 
  " Ano(s): " + Anos + "<br>" + 
  " Mês(es): " + Meses + "<br>" + 
  " dia(s): " + dias;
}

btCalcular.onclick = function() {
    Calcular();
}